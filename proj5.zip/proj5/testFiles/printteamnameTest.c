/*
 *Created by: Shurjo Maitra (sm47)
 *Date: 4/27/17
 *Runs teamname function in kernel
 */
#include <printteamname.h>
#include <stdio.h>

int main(void) {
	PRINTTEAMNAME;
	perror("FAILURE");
}